# T01：JEV 模块上游输入契约

版本：`1.1`（第一版开发期可选字段扩展）  
日期：2026-10-09（Australia/Sydney）  
状态：D01 已确认，输入类型和校验已实现；T03 用户确认平台等级来源，增加可选字段，已有 v1 输入仍可读取。  
保存：仅本地，不加入 Git。所有样例均为合成数据，不含凭证。

## 目标与边界

上游按本契约交付内容，本模块随后负责检查和打包，再送入 JEV。上游不需要了解 JEV 的问题类型或服务商请求格式。

本契约是**上游到本模块的输入**，不是 JEV HTTP 请求，也不是 JEV 输出格式。服务商请求由 T04、T05 构造；输出由 T02 约定。

每份输入描述一条待判断帖子。批量评估由本模块在 T07 组装，多条帖子仍各自拥有独立输入与标识。

平台 API 映射、正文获取、父帖和评论查询、实时事件获取由上游负责。本模块只接收已有材料；不足时报告缺失信息，不主动查询平台。

## 第一版约定

1. 必填仅包括：契约版本、帖子 ID、帖子正文、内容来源类型和观察时间。
2. 作者、发布时间、互动量、父帖、评论、互动历史和可信背景为可选材料。
3. 可选材料缺失时接受输入，仅执行信息支持的判断。基础分类不自动等于可以判断收益或值得回复。
4. 空正文或不可靠的核心标识直接退回，不调用 JEV。
5. 回复帖子缺少父帖时不默认拒绝；对依赖父帖的判断标记信息不足。
6. 第一版处理文本；媒体内容的理解与描述生成由上游负责，不由本模块加载图片、链接或音视频。

用户已确认 D01：允许基础分类，缺失信息限制判断范围。上述字段和校验规则作为第一版工程约定；后续如需修改，记录变更，不把缺失上下文重新设为所有输入的拒收条件。

## 顶层与核心字段

类型采用 JSON 的对象、数组、字符串、整数和 null。路径表示嵌套字段，不要求上游使用特定 Python 框架。

| 字段路径 | 类型 | 必填 | 含义与约束 |
|---|---|---|---|
| `schema_version` | 字符串 | 是 | 本契约第一版使用 `jev-input.v1`；文档修订号另记，不混入业务版本 |
| `post` | 对象 | 是 | 当前待判断帖子 |
| `post.post_id` | 非空字符串 | 是 | 上游提供的稳定、不可随意改写的标识；只做关联，不推断格式 |
| `post.text` | 非空字符串 | 是 | 当前帖子原文；仅空白不合格，不用补写或猜测的原文替代 |
| `source` | 对象 | 是 | 当前帖子材料的来源信息 |
| `source.kind` | 字符串 | 是 | `platform`：平台观测；`synthetic`：合成样例；`manual`：人工整理。来源不代表可信度 |
| `source.observed_at` | 日期时间字符串 | 是 | 材料被观察或采集的时间；带时区的 ISO 8601，如 `2026-10-09T10:00:00+11:00` |
| `source.source_id` | 字符串或 null | 否 | 上游采集记录或材料批次标识；不得放密钥或含凭证的 URL |
| `post.author_id` | 非空字符串或 null | 否 | 平台内公开标识，未知时省略或 null；不要求真实姓名 |
| `post.created_at` | 日期时间字符串或 null | 否 | 帖子发布时间，要求带时区；未知时不使用观察时间代替 |
| `post.kind` | 字符串或 null | 否 | `original`、`reply`、`quote`、`repost`、`unknown`；不得依据缺少父帖就认定原创 |
| `post.parent_id` | 非空字符串或 null | 否 | 已知父帖标识；标识存在不代表父帖正文已提供 |
| `post.hashtags` | 字符串数组或 null | 否 | 已提取的标签；空数组只表示已知未提供标签，不用于判断主题不存在 |
| `post.text_complete` | 布尔值或 null | 否 | true：上游确认正文完整；false：已知截断；省略或 null：完整性未知 |
| `author` | 对象或 null | 否 | 当前作者的可选公开信息 |
| `metrics` | 对象或 null | 否 | 当前帖子的可选互动快照 |
| `conversation` | 对象或 null | 否 | 上游已提供的父帖、引用与评论材料 |
| `interaction_history` | 对象或 null | 否 | 我方已知互动历史；不是最终重复发布检查 |
| `task_context` | 对象或 null | 否 | 调用方明确指定的赛事任务背景 |
| `trusted_background` | 对象或 null | 否 | 经本地可信来源核对后才可使用的参考材料 |

帖子 ID 的唯一范围由 `source.kind` 和 `post.post_id` 共同区分。真实平台目前只接一个比赛平台；如未来增加平台，再升级来源命名规则。帖子 ID 不作为内容缓存的唯一依据；相同 ID 的正文或上下文可能变化。

第一版仅接收表中明确的字段；未知字段作为契约不匹配退回，不静默转成模型上下文。新增字段先修订契约，避免上游将凭证或内部状态通过任意字段传入。

## 可选材料及约束

### 作者公开信息

| 字段 | 类型 | 含义 |
|---|---|---|
| `author.profile_text` | 字符串或 null | 上游取得的公开简介，作为不可信内容 |
| `author.followers_count` | 非负整数或 null | 已观察到的数量；不能由未知值补零 |
| `author.platform_level` | 非空字符串或 null | 上游明确从平台取得的等级标签；缺失未知，不根据简介、关注数或互动量推断，不自创高级／低级映射。平台原始字段转换由上游负责 |
| `author.observed_at` | 带时区日期时间或 null | 该资料的观察时间；不能直接沿用当前帖子抓取时间 |

不要求公民／机器人真值、内部立场、隐藏属性或现实身份。已有 `author_is_npc` 推断不作为必填或可信标签输入；相关判断在问题集讨论时单独处理。

### 互动快照

| 字段 | 类型 | 含义 |
|---|---|---|
| `metrics.likes` | 非负整数或 null | 观察到的点赞数 |
| `metrics.reposts` | 非负整数或 null | 观察到的转发数 |
| `metrics.replies` | 非负整数或 null | 观察到的回复数 |
| `metrics.observed_at` | 带时区日期时间或 null | 快照时间；省略时新鲜程度未知 |

只提供其中一项也可接受。没有互动量不影响基础主题分类，但不能据此断言帖子零热度。

### 父帖、引用与评论

`conversation` 包含 `status` 和 `items`。非 null 时两者必填。

| 字段 | 类型 | 含义 |
|---|---|---|
| `conversation.status` | 字符串 | `available`：已提供所声明范围的材料；`partial`：已知不完整；`not_provided`：没有提供；`not_applicable`：已确认不适用 |
| `conversation.items` | 数组 | 可为空；顺序由条目角色和时间解释，不假定返回顺序代表对话顺序 |
| 每条 `role` | 字符串 | `parent`、`quoted`、`comment` 或 `related`，必填 |
| 每条 `post_id` | 非空字符串 | 材料自身标识，必填 |
| 每条 `text` | 非空字符串 | 材料原文，必填 |
| 每条 `author_id` | 非空字符串或 null | 可选 |
| 每条 `created_at` | 带时区日期时间或 null | 可选 |
| 每条 `text_complete` | 布尔值或 null | 可选，语义与当前正文相同 |
| 每条 `source` | 对象 | 必填；结构同核心来源，说明每条材料实际来源及观察时间 |

`available` 只说明提供的材料可用，不宣称全平台对话已抓取完整。`not_provided` 或 `not_applicable` 时 `items` 必须为空。父帖条目如存在，需与已提供的 `post.parent_id` 一致；父帖不得与当前帖子拥有相同 ID。空数组不能单独被解释成“没有评论”。

### 我方互动历史

`interaction_history` 非 null 时必须包含 `status` 和 `events`。`status` 为 `available`、`partial` 或 `not_provided`；没有提供时事件数组为空。

每个事件包括必填的 `kind`（`reply`、`like` 或 `repost`）、`target_post_id`、`acted_at`（带时区时间），以及可选的 `text`（字符串或 null）。事件为上游已提供记录，不代表其他账号从未互动；即使列表为空，也不授权发布或保证没有重复回复。

### 任务背景与可信材料

| 字段 | 类型 | 含义 |
|---|---|---|
| `task_context.assigned_side` | 字符串或 null | `yes`、`no` 或 `unknown`，由调用方明确提供；不从帖子猜我方阵营 |
| `trusted_background.items` | 数组 | 非 null 的背景对象必须包含此数组；每条参考材料独立记录来源 |
| 每条 `reference_id` | 非空字符串 | 必填，参考材料标识 |
| 每条 `text` | 非空字符串 | 必填，参考正文 |
| 每条 `source_id` | 非空字符串 | 必填，供本地可信来源配置核对 |

可选对象即使存在，也不要求其中每个可选字段都有值。阵营未知时仍可做不依赖我方阵营的判断。可信材料缺失时不阻止基础分类，也不使用平台言论填充官方事实。

字段名为 `trusted_background` 不足以建立信任。T04 必须按本地受控资料核对引用标识、来源与内容；未经验证的材料不进入可信背景。第一版不接收平台内容自动写入可信资料库，也不自行打开参考链接。

## 缺失、零值、截断与拒收规则

| 输入情况 | 第一版处理 | 可以继续什么 |
|---|---|---|
| 必填字段缺失、空白 ID／正文或类型错误 | 拒收，不调用 JEV | 退回修正 |
| 契约版本不支持、字段未定义 | 拒收，说明不匹配项 | 修订契约或输入 |
| 已提供的可选字段类型错误、计数为负、时间不带时区 | 拒收，不悄悄删掉错误值 | 退回修正 |
| 可选字段省略或 null | 接受并标记未知 | 仅做现有信息支持的判断 |
| 已知点赞数为 0 | 接受，保留真实零值 | 可以使用该快照，但不是未来收益结论 |
| 已知是回复，父帖正文未提供 | 接受并标记缺少父帖 | 可做基础判断；依赖父帖的项目需补充或不判断 |
| 正文已截断但非空 | 接受并标记截断 | 不宣称完整理解；依赖遗漏部分的判断暂缓 |
| 互动快照没有采集时间 | 接受并标记新鲜程度未知 | 不把它当作实时热度 |
| 没有我方历史 | 接受并标记未知 | 不得据此断言此前没有回复 |
| 只有图片／视频链接，没有帖子原文 | 第一版拒收文本评估 | 上游提供可用文本；媒体解析另属上游 |
| 可信资料未经本地核对 | 不用作可信依据，保留缺失说明 | 不依赖它的基础判断仍可继续 |

字符串类型不接受数字或布尔值自动转字符串；整数计数不接受布尔值。省略和 null 都表示未知，但不能把明确的无效值悄悄转换成未知。具体信息不足的输出字段在 T02 定义，此处只约定输入行为。

长度上限、评论数量、时效窗口和打包优先级留到 T04／D06，不在 T01 猜测平台限制。

## 合成数据样例

以下 JSON 只是输入数据样例，不是业务代码，也不发送到任何服务。

### A：包含主要上下文的有效输入

预期：接收；可以评估当前表达及已提供的父帖、评论。资料仍是合成数据，不能当作比赛事实；作者类型和未来收益仍未知。

```json
{
  "schema_version": "jev-input.v1",
  "post": {
    "post_id": "demo-reply-002",
    "text": "What evidence supports that claim? I would like to understand the reasoning.",
    "author_id": "demo-author-b",
    "created_at": "2026-10-09T09:55:00+11:00",
    "kind": "reply",
    "parent_id": "demo-parent-001",
    "hashtags": [],
    "text_complete": true
  },
  "source": {
    "kind": "synthetic",
    "observed_at": "2026-10-09T10:00:00+11:00",
    "source_id": "t01-fixtures"
  },
  "author": {
    "profile_text": "A fictional account used only for input examples.",
    "followers_count": 18,
    "observed_at": "2026-10-09T09:50:00+11:00"
  },
  "metrics": {
    "likes": 2,
    "reposts": 0,
    "replies": 1,
    "observed_at": "2026-10-09T10:00:00+11:00"
  },
  "conversation": {
    "status": "partial",
    "items": [
      {
        "role": "parent",
        "post_id": "demo-parent-001",
        "text": "I think the proposal deserves discussion, but I have not shared my sources yet.",
        "author_id": "demo-author-a",
        "created_at": "2026-10-09T09:45:00+11:00",
        "text_complete": true,
        "source": {
          "kind": "synthetic",
          "observed_at": "2026-10-09T10:00:00+11:00",
          "source_id": "t01-fixtures"
        }
      },
      {
        "role": "comment",
        "post_id": "demo-comment-003",
        "text": "I also want to see the sources.",
        "author_id": "demo-author-c",
        "created_at": "2026-10-09T09:58:00+11:00",
        "text_complete": true,
        "source": {
          "kind": "synthetic",
          "observed_at": "2026-10-09T10:00:00+11:00",
          "source_id": "t01-fixtures"
        }
      }
    ]
  },
  "interaction_history": {
    "status": "partial",
    "events": [
      {
        "kind": "reply",
        "target_post_id": "demo-parent-001",
        "acted_at": "2026-10-09T09:52:00+11:00",
        "text": "Which part would you like to discuss?"
      }
    ]
  },
  "task_context": {
    "assigned_side": "unknown"
  }
}
```

这里未提供可信背景，因为没有为合成样例注册本地可信资料。可信资料从 T03／T04 的受控内容方案确定后再补充有效样例，不虚构已验证的来源。

### B：缺少可选材料的最小有效输入

预期：接收用于基础判断；作者、发布时间、热度、父帖、历史、阵营和正文完整性未知，不据此得出收益或发布结论。

```json
{
  "schema_version": "jev-input.v1",
  "post": {
    "post_id": "demo-minimal-001",
    "text": "Can someone explain what this proposal would change?"
  },
  "source": {
    "kind": "synthetic",
    "observed_at": "2026-10-09T10:00:00+11:00"
  }
}
```

### C：结构或值无效的输入

预期：拒收；不调用 JEV。错误包括版本缺失、ID 为空、正文仅空白、来源类型不存在、时间没有时区以及点赞数为负。

```json
{
  "post": {
    "post_id": "",
    "text": "   "
  },
  "source": {
    "kind": "unknown-provider",
    "observed_at": "2026-10-09T10:00:00"
  },
  "metrics": {
    "likes": -1
  }
}
```

## 与现有 Post 的关系

参考现有 [models.py](/Users/shaelyn/Documents/Projects/CNT2026/ctn/models.py)。此次不修改它。

| 现有字段 | 契约对应 | 注意 |
|---|---|---|
| `post_id`、`text`、`author` | 当前帖子 ID、正文、作者标识 | 本模块不负责从平台响应提取它们 |
| `created_at` | `post.created_at` | 现有数字时间由上游明确转换；默认 0 不能当成真实发布时间 |
| `likes`、`reposts`、`replies` | `metrics` 对应字段 | 现有默认 0 无法证明真实零值；上游需要保留是否实际观察到的信息 |
| `hashtags` | `post.hashtags` | 标签不代替正文 |
| `author_is_npc` | 无直接真值映射 | 不把本地推断升级为确定身份 |
| `raw` | 不直接传入 | 上游只交契约明确字段，不将整个原始响应带入模型 |

观察时间、来源和对话信息需要由上游明确提供。不能仅凭现有 `Post` 的默认值无损构造本契约输入；这一点属于上游交付要求，不增加平台映射任务。

## 已确认的用户决策 D01

确认日期：2026-10-09。用户选择：**允许基础分类，缺失信息限制判断范围。**

具体落实：允许最小有效输入，上下文可选；缺失或截断时只评估现有材料支持的项目，依赖缺失信息的判断标记信息不足。回复帖缺少父帖正文不会被默认拒收。上游可后续补充材料，本模块不自行查询平台。

无需现在决定最终评分标准、prompt、回复阈值或接口限额，它们属于后续任务。

## T01 交付与验收

- [x] 说明上游／本模块／下游边界。
- [x] 提出核心字段、可选材料、类型和来源规则。
- [x] 区分缺失、零值、无效值和截断。
- [x] 提供包含上下文、最小有效、无效输入三类合成样例。
- [x] 记录现有 Post 默认值与输入契约的差异。
- [x] D01 经用户确认，更新为确定方案。
- [x] 按确认结果复核字段和样例，冻结输入契约第一版。

输入类型与运行时校验已在 `ctn/jev/inputs.py` 实现，输入层现有 21 项测试通过；T04 负责后续请求打包。程序测试验证类型、缺失与无效值处理，不验证 JEV 分类效果。

## 版本记录

| 日期 | 文档版本 | 变化 |
|---|---|---|
| 2026-10-09 | `0.1-draft` | 提出字段、缺失处理、合成样例与 D01 推荐方案 |
| 2026-10-09 | `1.0` | 记录用户对 D01 的确认；复核上下文可选和信息不足规则，冻结输入第一版；数据中的 `schema_version` 保持 `jev-input.v1` |
| 2026-10-09 | `1.1` | T03 用户确认等级只采用平台明确信息、缺失未知；增加可选 `author.platform_level` 及校验，已有输入无需补字段，开发期 schema 保持 v1；三个新测试覆盖保留、不推断与无效值拒收 |
